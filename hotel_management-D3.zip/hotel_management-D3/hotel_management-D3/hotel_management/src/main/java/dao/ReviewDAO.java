// src/dao/ReviewDAO.java
package dao;

import model.Review;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReviewDAO {

    public Review create(Review review) throws SQLException {
        String sql = """
            INSERT INTO reviews (booking_id, guest_id, room_id, rating, comment)
            VALUES (?, ?, ?, ?, ?)
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, review.getBookingId());
            stmt.setInt(2, review.getGuestId());
            stmt.setInt(3, review.getRoomId());
            stmt.setInt(4, review.getRating());
            stmt.setString(5, review.getComment());
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) review.setId(keys.getInt(1));
            }
        }
        return review;
    }

    public List<Review> findAll() throws SQLException {
        List<Review> list = new ArrayList<>();
        String sql = """
            SELECT rv.*, u.name as guest_name, r.room_number
            FROM reviews rv
            JOIN users u ON rv.guest_id = u.id
            JOIN rooms r ON rv.room_id = r.id
            ORDER BY rv.created_at DESC
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        }
        return list;
    }

    public List<Review> findByGuestId(int guestId) throws SQLException {
        List<Review> list = new ArrayList<>();
        String sql = """
            SELECT rv.*, u.name as guest_name, r.room_number
            FROM reviews rv
            JOIN users u ON rv.guest_id = u.id
            JOIN rooms r ON rv.room_id = r.id
            WHERE rv.guest_id = ?
            ORDER BY rv.created_at DESC
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, guestId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) list.add(mapResultSet(rs));
        }
        return list;
    }

    public boolean hasReviewedBooking(int bookingId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM reviews WHERE booking_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bookingId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        }
        return false;
    }

    private Review mapResultSet(ResultSet rs) throws SQLException {
        Review rv = new Review();
        rv.setId(rs.getInt("id"));
        rv.setBookingId(rs.getInt("booking_id"));
        rv.setGuestId(rs.getInt("guest_id"));
        rv.setRoomId(rs.getInt("room_id"));
        rv.setGuestName(rs.getString("guest_name"));
        rv.setRoomNumber(rs.getString("room_number"));
        rv.setRating(rs.getInt("rating"));
        rv.setComment(rs.getString("comment"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) rv.setCreatedAt(ts.toLocalDateTime());
        return rv;
    }
}
