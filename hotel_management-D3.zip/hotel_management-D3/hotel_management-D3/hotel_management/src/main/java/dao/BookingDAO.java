// src/dao/BookingDAO.java
package dao;

import model.Booking;
import model.Room;
import util.DatabaseConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {

    public Booking create(Booking booking) throws SQLException {
        String sql = """
            INSERT INTO bookings (guest_id, room_id, check_in_date, check_out_date,
                price_per_night, subtotal, tax_amount, total_amount, payment_status, booking_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, booking.getGuestId());
            stmt.setInt(2, booking.getRoomId());
            stmt.setDate(3, Date.valueOf(booking.getCheckInDate()));
            stmt.setDate(4, Date.valueOf(booking.getCheckOutDate()));
            stmt.setBigDecimal(5, booking.getPricePerNight());
            stmt.setBigDecimal(6, booking.getSubtotal());
            stmt.setBigDecimal(7, booking.getTaxAmount());
            stmt.setBigDecimal(8, booking.getTotalAmount());
            stmt.setString(9, booking.getPaymentStatus().name());
            stmt.setString(10, booking.getBookingStatus().name());

            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) booking.setId(keys.getInt(1));
            }
        }
        return booking;
    }

    public Booking findById(int id) throws SQLException {
        String sql = """
            SELECT b.*, u.name as guest_name, r.room_number, r.type as room_type
            FROM bookings b
            JOIN users u ON b.guest_id = u.id
            JOIN rooms r ON b.room_id = r.id
            WHERE b.id = ?
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return mapResultSet(rs);
        }
        return null;
    }

    public List<Booking> findByGuestId(int guestId) throws SQLException {
        List<Booking> list = new ArrayList<>();
        String sql = """
            SELECT b.*, u.name as guest_name, r.room_number, r.type as room_type
            FROM bookings b
            JOIN users u ON b.guest_id = u.id
            JOIN rooms r ON b.room_id = r.id
            WHERE b.guest_id = ?
            ORDER BY b.created_at DESC
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, guestId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) list.add(mapResultSet(rs));
        }
        return list;
    }

    public List<Booking> findAll() throws SQLException {
        List<Booking> list = new ArrayList<>();
        String sql = """
            SELECT b.*, u.name as guest_name, r.room_number, r.type as room_type
            FROM bookings b
            JOIN users u ON b.guest_id = u.id
            JOIN rooms r ON b.room_id = r.id
            ORDER BY b.created_at DESC
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        }
        return list;
    }

    public List<Booking> findByDateRange(LocalDate from, LocalDate to) throws SQLException {
        List<Booking> list = new ArrayList<>();
        String sql = """
            SELECT b.*, u.name as guest_name, r.room_number, r.type as room_type
            FROM bookings b
            JOIN users u ON b.guest_id = u.id
            JOIN rooms r ON b.room_id = r.id
            WHERE b.check_in_date >= ? AND b.check_in_date <= ?
            ORDER BY b.check_in_date DESC
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(from));
            stmt.setDate(2, Date.valueOf(to));
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) list.add(mapResultSet(rs));
        }
        return list;
    }

    public void updatePaymentStatus(int bookingId, Booking.PaymentStatus status) throws SQLException {
        String sql = "UPDATE bookings SET payment_status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status.name());
            stmt.setInt(2, bookingId);
            stmt.executeUpdate();
        }
    }

    public void updateBookingStatus(int bookingId, Booking.BookingStatus status) throws SQLException {
        String sql = "UPDATE bookings SET booking_status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status.name());
            stmt.setInt(2, bookingId);
            stmt.executeUpdate();
        }
    }

    public BigDecimal getTotalRevenueBetween(LocalDate from, LocalDate to) throws SQLException {
        String sql = """
            SELECT COALESCE(SUM(total_amount), 0) FROM bookings
            WHERE check_in_date >= ? AND check_in_date <= ?
            AND payment_status = 'PAID'
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(from));
            stmt.setDate(2, Date.valueOf(to));
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getBigDecimal(1);
        }
        return BigDecimal.ZERO;
    }

    /** Returns list of [room_type, booking_count, occupancy_pct] */
    public List<Object[]> getRoomOccupancyStats() throws SQLException {
        List<Object[]> stats = new ArrayList<>();
        String sql = """
            SELECT r.type,
                   COUNT(b.id) as booking_count,
                   COUNT(DISTINCT r.id) as total_rooms
            FROM rooms r
            LEFT JOIN bookings b ON b.room_id = r.id
                AND b.booking_status IN ('RESERVED','CHECKED_IN','COMPLETED')
            GROUP BY r.type
            ORDER BY booking_count DESC
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                stats.add(new Object[]{
                    rs.getString("type"),
                    rs.getInt("booking_count"),
                    rs.getInt("total_rooms")
                });
            }
        }
        return stats;
    }

    private Booking mapResultSet(ResultSet rs) throws SQLException {
        Booking b = new Booking();
        b.setId(rs.getInt("id"));
        b.setGuestId(rs.getInt("guest_id"));
        b.setRoomId(rs.getInt("room_id"));
        b.setGuestName(rs.getString("guest_name"));
        b.setRoomNumber(rs.getString("room_number"));
        b.setRoomType(Room.RoomType.valueOf(rs.getString("room_type")));
        b.setCheckInDate(rs.getDate("check_in_date").toLocalDate());
        b.setCheckOutDate(rs.getDate("check_out_date").toLocalDate());
        b.setPricePerNight(rs.getBigDecimal("price_per_night"));
        b.setSubtotal(rs.getBigDecimal("subtotal"));
        b.setTaxAmount(rs.getBigDecimal("tax_amount"));
        b.setTotalAmount(rs.getBigDecimal("total_amount"));
        b.setPaymentStatus(Booking.PaymentStatus.valueOf(rs.getString("payment_status")));
        b.setBookingStatus(Booking.BookingStatus.valueOf(rs.getString("booking_status")));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) b.setCreatedAt(ts.toLocalDateTime());
        return b;
    }
}
