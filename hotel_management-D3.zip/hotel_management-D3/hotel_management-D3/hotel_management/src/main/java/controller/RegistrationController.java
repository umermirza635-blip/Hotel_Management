// src/controller/RegistrationController.java
package controller;

import model.User;
import service.AuthService;

import java.sql.SQLException;

public class RegistrationController {
    private AuthService authService;

    public RegistrationController() {
        this.authService = new AuthService();
    }

    public RegistrationResult register(String name, String email, String password, User.UserRole role) {
        try {
            User user = authService.register(name, email, password, role);
            return new RegistrationResult(true, "Registration successful", user);
        } catch (IllegalArgumentException e) {
            return new RegistrationResult(false, e.getMessage(), null);
        } catch (SQLException e) {
            return new RegistrationResult(false, "Database error: " + e.getMessage(), null);
        }
    }

    public static class RegistrationResult {
        private boolean success;
        private String message;
        private User user;

        public RegistrationResult(boolean success, String message, User user) {
            this.success = success;
            this.message = message;
            this.user = user;
        }

        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public User getUser() { return user; }
    }
}