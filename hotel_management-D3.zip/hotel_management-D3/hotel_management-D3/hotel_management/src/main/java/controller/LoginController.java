// src/controller/LoginController.java
package controller;

import model.User;
import service.AuthService;

import java.sql.SQLException;

public class LoginController {
    private AuthService authService;

    public LoginController() {
        this.authService = new AuthService();
    }

    public LoginResult login(String email, String password) {
        try {
            User user = authService.login(email, password);
            return new LoginResult(true, "Login successful", user);
        } catch (IllegalArgumentException e) {
            return new LoginResult(false, e.getMessage(), null);
        } catch (SQLException e) {
            return new LoginResult(false, "Database error: " + e.getMessage(), null);
        }
    }

    public static class LoginResult {
        private boolean success;
        private String message;
        private User user;

        public LoginResult(boolean success, String message, User user) {
            this.success = success;
            this.message = message;
            this.user = user;
        }

        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public User getUser() { return user; }
    }
}