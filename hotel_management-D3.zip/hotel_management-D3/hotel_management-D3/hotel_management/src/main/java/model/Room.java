// src/model/Room.java
package model;

import java.math.BigDecimal;

public class Room {
    private int id;
    private String roomNumber;
    private RoomType type;
    private BigDecimal price;
    private RoomStatus status;
    private int capacity;
    private String description;
    private String amenities;

    public enum RoomType {
        SINGLE("Single Room"),
        DOUBLE("Double Room"),
        SUITE("Suite"),
        DELUXE("Deluxe Room"),
        FAMILY("Family Room");

        private final String displayName;
        RoomType(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }

    public enum RoomStatus {
        AVAILABLE("Available"),
        OCCUPIED("Occupied"),
        MAINTENANCE("Under Maintenance"),
        RESERVED("Reserved");

        private final String displayName;
        RoomStatus(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }

    public Room() {}

    public Room(String roomNumber, RoomType type, BigDecimal price, int capacity) {
        this.roomNumber = roomNumber;
        this.type = type;
        this.price = price;
        this.capacity = capacity;
        this.status = RoomStatus.AVAILABLE;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public RoomType getType() { return type; }
    public void setType(RoomType type) { this.type = type; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public RoomStatus getStatus() { return status; }
    public void setStatus(RoomStatus status) { this.status = status; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getAmenities() { return amenities; }
    public void setAmenities(String amenities) { this.amenities = amenities; }

    @Override
    public String toString() {
        return "Room " + roomNumber + " - " + type.getDisplayName();
    }
}