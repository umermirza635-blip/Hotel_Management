// src/view/BookingView.java
package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Booking;
import model.Room;
import model.User;
import service.BookingService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class BookingView {

    private final Stage owner;
    private final Room room;
    private final User guest;
    private final BookingService bookingService;
    private Runnable onBookingComplete;

    public BookingView(Stage owner, Room room, User guest) {
        this.owner = owner;
        this.room = room;
        this.guest = guest;
        this.bookingService = new BookingService();
    }

    public void setOnBookingComplete(Runnable callback) {
        this.onBookingComplete = callback;
    }

    public void show() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(owner);
        dialog.setTitle("Book Room " + room.getRoomNumber());

        VBox root = new VBox(20);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: #f5f6fa;");

        // Header
        Label title = new Label("📅  Book Room " + room.getRoomNumber());
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        title.setTextFill(Color.web("#2c3e50"));

        // Room Info Card
        VBox infoCard = new VBox(8);
        infoCard.setPadding(new Insets(15));
        infoCard.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 10;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 3);
            """);
        infoCard.getChildren().addAll(
            boldLabel("Room: " + room.getRoomNumber() + " — " + room.getType().getDisplayName()),
            new Label("Price: PKR " + room.getPrice() + " per night"),
            new Label("Capacity: " + room.getCapacity() + " guest(s)")
        );

        // Date pickers
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(12);
        grid.setPadding(new Insets(15));
        grid.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 10;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 3);
            """);

        DatePicker checkInPicker = new DatePicker(LocalDate.now());
        DatePicker checkOutPicker = new DatePicker(LocalDate.now().plusDays(1));

        Label summaryLabel = new Label("Select dates to see price breakdown");
        summaryLabel.setWrapText(true);

        // Auto-update summary when dates change
        Runnable updateSummary = () -> {
            LocalDate in = checkInPicker.getValue();
            LocalDate out = checkOutPicker.getValue();
            if (in != null && out != null && out.isAfter(in)) {
                long nights = ChronoUnit.DAYS.between(in, out);
                BigDecimal subtotal = room.getPrice().multiply(BigDecimal.valueOf(nights));
                BigDecimal gst = subtotal.multiply(BookingService.GST_RATE).setScale(2, RoundingMode.HALF_UP);
                BigDecimal svc = subtotal.multiply(BookingService.SERVICE_CHARGE_RATE).setScale(2, RoundingMode.HALF_UP);
                BigDecimal total = subtotal.add(gst).add(svc);
                summaryLabel.setText(String.format(
                    "Nights: %d  |  Subtotal: PKR %,.2f\nGST (16%%): PKR %,.2f  |  Service (5%%): PKR %,.2f\n★ TOTAL: PKR %,.2f",
                    nights, subtotal, gst, svc, total));
                summaryLabel.setTextFill(Color.web("#27ae60"));
            } else {
                summaryLabel.setText("⚠ Check-out must be after check-in.");
                summaryLabel.setTextFill(Color.RED);
            }
        };

        checkInPicker.valueProperty().addListener((obs, o, n) -> updateSummary.run());
        checkOutPicker.valueProperty().addListener((obs, o, n) -> updateSummary.run());
        updateSummary.run();

        grid.addRow(0, boldLabel("Check-In:"), checkInPicker);
        grid.addRow(1, boldLabel("Check-Out:"), checkOutPicker);
        grid.addRow(2, boldLabel("Summary:"), summaryLabel);

        // Action buttons
        HBox btnBox = new HBox(10);
        btnBox.setAlignment(Pos.CENTER_RIGHT);

        Button confirmBtn = new Button("✅  Confirm Booking");
        confirmBtn.setStyle("""
            -fx-background-color: #27ae60;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 25;
            -fx-font-size: 14;
            -fx-cursor: hand;
            """);

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setStyle("""
            -fx-background-color: #7f8c8d;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 25;
            -fx-font-size: 14;
            -fx-cursor: hand;
            """);
        cancelBtn.setOnAction(e -> dialog.close());

        confirmBtn.setOnAction(e -> {
            LocalDate in = checkInPicker.getValue();
            LocalDate out = checkOutPicker.getValue();
            try {
                Booking booking = bookingService.createBooking(guest.getId(), room.getId(), in, out);
                dialog.close();
                // Show invoice immediately
                // Enrich booking with display info
                booking.setGuestName(guest.getName());
                booking.setRoomNumber(room.getRoomNumber());
                booking.setRoomType(room.getType());
                new InvoiceView(booking).show();
                if (onBookingComplete != null) onBookingComplete.run();
            } catch (Exception ex) {
                showAlert(dialog, Alert.AlertType.ERROR, "Booking Failed", ex.getMessage());
            }
        });

        btnBox.getChildren().addAll(confirmBtn, cancelBtn);

        root.getChildren().addAll(title, infoCard, grid, btnBox);

        Scene scene = new Scene(root, 500, 420);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private Label boldLabel(String text) {
        Label lbl = new Label(text);
        lbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 13));
        return lbl;
    }

    private void showAlert(Stage owner, Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
