// src/view/RegistrationView.java
package view;

import controller.RegistrationController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.User;

public class RegistrationView {
    private Stage stage;
    private RegistrationController controller;
    private TextField nameField;
    private TextField emailField;
    private PasswordField passwordField;
    private PasswordField confirmPasswordField;
    private ComboBox<String> roleCombo;
    private Label messageLabel;

    public RegistrationView(Stage stage) {
        this.stage = stage;
        this.controller = new RegistrationController();
    }

    public void show() {
        VBox mainContainer = new VBox(20);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setPadding(new Insets(40));
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom right, #1e3c72, #2a5298);
            """);

        VBox registerCard = new VBox(15);
        registerCard.setAlignment(Pos.CENTER);
        registerCard.setPadding(new Insets(30));
        registerCard.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 15;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 20, 0, 0, 10);
            """);
        registerCard.setMaxWidth(450);

        Label titleLabel = new Label("Create Account");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#1e3c72"));

        // Form
        GridPane formGrid = new GridPane();
        formGrid.setVgap(10);
        formGrid.setHgap(10);
        formGrid.setAlignment(Pos.CENTER);

        nameField = createStyledTextField("Full Name");
        emailField = createStyledTextField("Email Address");
        passwordField = createStyledPasswordField("Password");
        confirmPasswordField = createStyledPasswordField("Confirm Password");

        roleCombo = new ComboBox<>();
        roleCombo.getItems().addAll("Guest", "Admin");
        roleCombo.setValue("Guest");
        roleCombo.setStyle("""
            -fx-background-color: #f5f5f5;
            -fx-background-radius: 5;
            -fx-padding: 8;
            """);

        formGrid.addRow(0, createLabel("Name:"), nameField);
        formGrid.addRow(1, createLabel("Email:"), emailField);
        formGrid.addRow(2, createLabel("Role:"), roleCombo);
        formGrid.addRow(3, createLabel("Password:"), passwordField);
        formGrid.addRow(4, createLabel("Confirm:"), confirmPasswordField);

        messageLabel = new Label();
        messageLabel.setTextFill(Color.RED);
        messageLabel.setWrapText(true);

        Button registerButton = new Button("Register");
        styleButton(registerButton);
        registerButton.setOnAction(e -> handleRegistration());

        Button backButton = new Button("Back to Login");
        backButton.setStyle("""
            -fx-background-color: transparent;
            -fx-text-fill: #666;
            -fx-cursor: hand;
            """);
        backButton.setOnAction(e -> new LoginView(stage).show());

        registerCard.getChildren().addAll(
            titleLabel, new Separator(), 
            formGrid, messageLabel, 
            registerButton, backButton
        );

        mainContainer.getChildren().add(registerCard);

        Scene scene = new Scene(mainContainer, 800, 600);
        stage.setScene(scene);
    }

    private Label createLabel(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        return label;
    }

    private TextField createStyledTextField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setStyle("""
            -fx-background-color: #f5f5f5;
            -fx-background-radius: 5;
            -fx-border-color: #ddd;
            -fx-border-radius: 5;
            -fx-padding: 8;
            """);
        return field;
    }

    private PasswordField createStyledPasswordField(String prompt) {
        PasswordField field = new PasswordField();
        field.setPromptText(prompt);
        field.setStyle("""
            -fx-background-color: #f5f5f5;
            -fx-background-radius: 5;
            -fx-border-color: #ddd;
            -fx-border-radius: 5;
            -fx-padding: 8;
            """);
        return field;
    }

    private void styleButton(Button button) {
        button.setStyle("""
            -fx-background-color: #28a745;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 40;
            -fx-font-size: 14;
            -fx-font-weight: bold;
            -fx-cursor: hand;
            """);
    }

    private void handleRegistration() {
        String name = nameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        User.UserRole role = roleCombo.getValue().equals("Admin") ? 
                            User.UserRole.ADMIN : User.UserRole.GUEST;

        if (!password.equals(confirmPassword)) {
            messageLabel.setText("Passwords do not match");
            return;
        }

        try {
            var result = controller.register(name, email, password, role);
            if (result.isSuccess()) {
                showAlert(Alert.AlertType.INFORMATION, "Success", 
                         "Registration successful! Please login.");
                new LoginView(stage).show();
            } else {
                messageLabel.setText(result.getMessage());
            }
        } catch (Exception e) {
            messageLabel.setText("Error: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}