// src/view/LoginView.java
package view;

import controller.LoginController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class LoginView {
    private Stage stage;
    private LoginController controller;
    private TextField emailField;
    private PasswordField passwordField;
    private Label messageLabel;
    private Runnable onLoginSuccess;

    public LoginView(Stage stage) {
        this.stage = stage;
        this.controller = new LoginController();
        createView();
    }

    private void createView() {
        // Main container with gradient background
        VBox mainContainer = new VBox(20);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setPadding(new Insets(40));
        mainContainer.setStyle("""
            -fx-background-color: linear-gradient(to bottom right, #1e3c72, #2a5298);
            """);

        // Login card
        VBox loginCard = new VBox(15);
        loginCard.setAlignment(Pos.CENTER);
        loginCard.setPadding(new Insets(30));
        loginCard.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 15;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 20, 0, 0, 10);
            """);
        loginCard.setMaxWidth(400);

        // Title
        Label titleLabel = new Label("Hotel Management System");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#1e3c72"));

        Label subtitleLabel = new Label("Sign in to your account");
        subtitleLabel.setFont(Font.font("Segoe UI", 14));
        subtitleLabel.setTextFill(Color.GRAY);

        // Form fields
        VBox formBox = new VBox(10);
        
        Label emailLabel = new Label("Email");
        emailLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        emailField = new TextField();
        emailField.setPromptText("Enter your email");
        styleTextField(emailField);

        Label passwordLabel = new Label("Password");
        passwordLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");
        styleTextField(passwordField);

        formBox.getChildren().addAll(emailLabel, emailField, passwordLabel, passwordField);

        // Message label for errors
        messageLabel = new Label();
        messageLabel.setTextFill(Color.RED);
        messageLabel.setWrapText(true);

        // Buttons
        Button loginButton = new Button("Sign In");
        stylePrimaryButton(loginButton);
        loginButton.setOnAction(e -> handleLogin());

        Button registerButton = new Button("Create Account");
        styleSecondaryButton(registerButton);
        registerButton.setOnAction(e -> showRegistration());

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(loginButton, registerButton);

        // Add all to card
        loginCard.getChildren().addAll(
            titleLabel, subtitleLabel, 
            new Separator(), 
            formBox, 
            messageLabel,
            buttonBox
        );

        mainContainer.getChildren().add(loginCard);

        Scene scene = new Scene(mainContainer, 800, 600);
        stage.setTitle("Hotel Management - Login");
        stage.setScene(scene);
        stage.setResizable(false);
    }

    private void styleTextField(TextField field) {
        field.setStyle("""
            -fx-background-color: #f5f5f5;
            -fx-background-radius: 5;
            -fx-border-color: #ddd;
            -fx-border-radius: 5;
            -fx-padding: 10;
            -fx-font-size: 14;
            """);
        field.setPrefHeight(40);
    }

    private void stylePrimaryButton(Button button) {
        button.setStyle("""
            -fx-background-color: #1e3c72;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 30;
            -fx-font-size: 14;
            -fx-font-weight: bold;
            -fx-cursor: hand;
            """);
        button.setOnMouseEntered(e -> button.setStyle("""
            -fx-background-color: #2a5298;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 30;
            -fx-font-size: 14;
            -fx-font-weight: bold;
            -fx-cursor: hand;
            """));
        button.setOnMouseExited(e -> button.setStyle("""
            -fx-background-color: #1e3c72;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 30;
            -fx-font-size: 14;
            -fx-font-weight: bold;
            -fx-cursor: hand;
            """));
    }

    private void styleSecondaryButton(Button button) {
        button.setStyle("""
            -fx-background-color: transparent;
            -fx-text-fill: #1e3c72;
            -fx-border-color: #1e3c72;
            -fx-border-radius: 5;
            -fx-padding: 12 30;
            -fx-font-size: 14;
            -fx-cursor: hand;
            """);
    }

    private void handleLogin() {
        String email = emailField.getText();
        String password = passwordField.getText();

        try {
            var result = controller.login(email, password);
            if (result.isSuccess()) {
                if (onLoginSuccess != null) {
                    onLoginSuccess.run();
                }
                navigateToDashboard(result.getUser());
            } else {
                messageLabel.setText(result.getMessage());
            }
        } catch (Exception e) {
            messageLabel.setText("Error: " + e.getMessage());
        }
    }

    private void showRegistration() {
        new RegistrationView(stage).show();
    }

    private void navigateToDashboard(model.User user) {
        if (user.getRole() == model.User.UserRole.ADMIN) {
            new AdminDashboardView(stage, user).show();
        } else {
            new GuestDashboardView(stage, user).show();
        }
    }

    public void setOnLoginSuccess(Runnable callback) {
        this.onLoginSuccess = callback;
    }

    public void show() {
        stage.show();
    }
}