// src/view/InvoiceView.java
package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Booking;
import service.InvoiceGenerator;

public class InvoiceView {

    private final Booking booking;

    public InvoiceView(Booking booking) {
        this.booking = booking;
    }

    public void show() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Invoice #" + String.format("%06d", booking.getId()));

        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #f5f6fa;");

        // Title bar
        HBox titleBar = new HBox(10);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        Label titleLbl = new Label("🧾  Invoice / Receipt");
        titleLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        titleLbl.setTextFill(Color.web("#2c3e50"));
        titleBar.getChildren().add(titleLbl);

        // Invoice text area
        TextArea invoiceArea = new TextArea();
        invoiceArea.setEditable(false);
        invoiceArea.setFont(Font.font("Courier New", 13));
        invoiceArea.setText(InvoiceGenerator.generateInvoiceText(booking));
        invoiceArea.setPrefRowCount(30);
        invoiceArea.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 5;
            -fx-background-radius: 5;
            """);

        // Buttons
        HBox btnBox = new HBox(10);
        btnBox.setAlignment(Pos.CENTER_RIGHT);

        Button saveBtn = new Button("💾  Save to File");
        saveBtn.setStyle("""
            -fx-background-color: #27ae60;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 10 20;
            -fx-font-size: 13;
            -fx-cursor: hand;
            """);
        saveBtn.setOnAction(e -> {
            try {
                String path = InvoiceGenerator.saveInvoiceToFile(booking);
                showAlert(dialog, Alert.AlertType.INFORMATION,
                        "Saved", "Invoice saved to:\n" + path);
            } catch (Exception ex) {
                showAlert(dialog, Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        Button closeBtn = new Button("Close");
        closeBtn.setStyle("""
            -fx-background-color: #7f8c8d;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 10 20;
            -fx-font-size: 13;
            -fx-cursor: hand;
            """);
        closeBtn.setOnAction(e -> dialog.close());

        btnBox.getChildren().addAll(saveBtn, closeBtn);

        root.getChildren().addAll(titleBar, invoiceArea, btnBox);

        Scene scene = new Scene(root, 600, 650);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void showAlert(Stage owner, Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
