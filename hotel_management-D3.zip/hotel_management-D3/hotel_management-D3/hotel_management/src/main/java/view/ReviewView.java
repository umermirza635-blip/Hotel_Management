// src/view/ReviewView.java
package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Booking;
import model.User;
import service.ReviewService;

public class ReviewView {

    private final Stage owner;
    private final Booking booking;
    private final User guest;
    private final ReviewService reviewService;
    private Runnable onReviewComplete;

    public ReviewView(Stage owner, Booking booking, User guest) {
        this.owner = owner;
        this.booking = booking;
        this.guest = guest;
        this.reviewService = new ReviewService();
    }

    public void setOnReviewComplete(Runnable callback) {
        this.onReviewComplete = callback;
    }

    public void show() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(owner);
        dialog.setTitle("Leave a Review");

        VBox root = new VBox(20);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: #f5f6fa;");

        Label title = new Label("⭐  Leave a Review");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        title.setTextFill(Color.web("#2c3e50"));

        Label subtitle = new Label("Room " + booking.getRoomNumber() + " — " +
                booking.getCheckInDate() + " to " + booking.getCheckOutDate());
        subtitle.setTextFill(Color.GRAY);

        // Star Rating row
        Label ratingLabel = new Label("Your Rating:");
        ratingLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));

        HBox starBox = new HBox(8);
        starBox.setAlignment(Pos.CENTER_LEFT);
        final int[] selectedRating = {0};
        Label[] stars = new Label[5];

        for (int i = 0; i < 5; i++) {
            final int starIndex = i + 1;
            Label star = new Label("☆");
            star.setFont(Font.font(30));
            star.setTextFill(Color.GRAY);
            star.setStyle("-fx-cursor: hand;");
            star.setOnMouseEntered(e -> highlightStars(stars, starIndex, true));
            star.setOnMouseExited(e -> highlightStars(stars, selectedRating[0], false));
            star.setOnMouseClicked(e -> {
                selectedRating[0] = starIndex;
                highlightStars(stars, starIndex, false);
            });
            stars[i] = star;
            starBox.getChildren().add(star);
        }

        Label ratingDisplay = new Label("Click a star to rate");
        ratingDisplay.setTextFill(Color.GRAY);

        // Comment area
        Label commentLabel = new Label("Your Comment:");
        commentLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));

        TextArea commentArea = new TextArea();
        commentArea.setPromptText("Tell us about your stay...");
        commentArea.setPrefRowCount(4);
        commentArea.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #ddd;
            -fx-border-radius: 5;
            -fx-background-radius: 5;
            """);

        // Buttons
        HBox btnBox = new HBox(10);
        btnBox.setAlignment(Pos.CENTER_RIGHT);

        Button submitBtn = new Button("Submit Review");
        submitBtn.setStyle("""
            -fx-background-color: #f39c12;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 25;
            -fx-font-size: 14;
            -fx-cursor: hand;
            """);
        submitBtn.setOnAction(e -> {
            if (selectedRating[0] == 0) {
                ratingDisplay.setText("Please select a star rating!");
                ratingDisplay.setTextFill(Color.RED);
                return;
            }
            try {
                reviewService.submitReview(
                        booking.getId(), guest.getId(), booking.getRoomId(),
                        selectedRating[0], commentArea.getText());
                showAlert(dialog, Alert.AlertType.INFORMATION, "Thank You!",
                        "Your review has been submitted.\nRating: " + "★".repeat(selectedRating[0]));
                dialog.close();
                if (onReviewComplete != null) onReviewComplete.run();
            } catch (Exception ex) {
                showAlert(dialog, Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setStyle("""
            -fx-background-color: #7f8c8d;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 25;
            -fx-font-size: 14;
            -fx-cursor: hand;
            """);
        cancelBtn.setOnAction(e -> dialog.close());
        btnBox.getChildren().addAll(submitBtn, cancelBtn);

        root.getChildren().addAll(
                title, subtitle, new Separator(),
                ratingLabel, starBox, ratingDisplay,
                commentLabel, commentArea,
                btnBox);

        Scene scene = new Scene(root, 450, 430);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void highlightStars(Label[] stars, int count, boolean hover) {
        for (int i = 0; i < 5; i++) {
            if (i < count) {
                stars[i].setText("★");
                stars[i].setTextFill(hover ? Color.GOLD : Color.ORANGE);
            } else {
                stars[i].setText("☆");
                stars[i].setTextFill(Color.GRAY);
            }
        }
    }

    private void showAlert(Stage owner, Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
