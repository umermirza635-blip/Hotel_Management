// src/view/GuestDashboardView.java
package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Booking;
import model.Room;
import model.User;
import service.BookingService;
import service.RoomService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;

public class GuestDashboardView {
    private Stage stage;
    private User currentUser;
    private RoomService roomService;
    private BookingService bookingService;
    private TableView<Room> roomTable;
    private ObservableList<Room> roomList;
    private TableView<Booking> bookingTable;
    private ObservableList<Booking> bookingList;

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public GuestDashboardView(Stage stage, User user) {
        this.stage = stage;
        this.currentUser = user;
        this.roomService = new RoomService();
        this.bookingService = new BookingService();
    }

    public void show() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f6fa;");
        root.setTop(createHeader());

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab browseTab = new Tab("🏠  Browse Rooms", createBrowseContent());
        Tab myBookingsTab = new Tab("📋  My Bookings", createMyBookingsContent());
        tabPane.getTabs().addAll(browseTab, myBookingsTab);

        myBookingsTab.setOnSelectionChanged(e -> {
            if (myBookingsTab.isSelected()) refreshBookingTable();
        });

        root.setCenter(tabPane);

        Scene scene = new Scene(root, 1200, 800);
        stage.setTitle("Guest Dashboard — " + currentUser.getName());
        stage.setScene(scene);
        stage.setMaximized(true);
    }

    private HBox createHeader() {
        HBox header = new HBox(20);
        header.setPadding(new Insets(15, 20, 15, 20));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setStyle("""
            -fx-background-color: linear-gradient(to right, #667eea, #764ba2);
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 5);
            """);

        Label titleLabel = new Label("🏨  Find Your Perfect Room");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        titleLabel.setTextFill(Color.WHITE);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label userLabel = new Label("Welcome, " + currentUser.getName());
        userLabel.setFont(Font.font("Segoe UI", 14));
        userLabel.setTextFill(Color.WHITE);

        Button logoutButton = new Button("Logout");
        logoutButton.setStyle("""
            -fx-background-color: rgba(255,255,255,0.2);
            -fx-text-fill: white;
            -fx-background-radius: 20;
            -fx-padding: 8 20;
            -fx-cursor: hand;
            """);
        logoutButton.setOnAction(e -> new LoginView(stage).show());

        header.getChildren().addAll(titleLabel, spacer, userLabel, logoutButton);
        return header;
    }

    private VBox createBrowseContent() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        HBox filterBox = createFilterSection();

        Label resultsLabel = new Label("Available Rooms");
        resultsLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));

        roomTable = createRoomTable();
        roomList = FXCollections.observableArrayList();
        roomTable.setItems(roomList);
        VBox.setVgrow(roomTable, Priority.ALWAYS);

        try {
            roomList.addAll(roomService.filterRooms(null, null, null));
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
        }

        content.getChildren().addAll(filterBox, resultsLabel, roomTable);
        return content;
    }

    private HBox createFilterSection() {
        HBox filterBox = new HBox(15);
        filterBox.setPadding(new Insets(20));
        filterBox.setAlignment(Pos.CENTER_LEFT);
        filterBox.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 10;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 5);
            """);

        VBox typeBox = new VBox(5);
        Label typeLabel = new Label("Room Type");
        typeLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        ComboBox<Room.RoomType> typeCombo = new ComboBox<>(
            FXCollections.observableArrayList(Room.RoomType.values()));
        typeCombo.setPromptText("Any Type");
        typeBox.getChildren().addAll(typeLabel, typeCombo);

        VBox priceBox = new VBox(5);
        Label priceLabel = new Label("Price Range (PKR)");
        priceLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        HBox priceInputs = new HBox(10);
        TextField minPrice = new TextField();
        minPrice.setPromptText("Min");
        minPrice.setPrefWidth(100);
        TextField maxPrice = new TextField();
        maxPrice.setPromptText("Max");
        maxPrice.setPrefWidth(100);
        priceInputs.getChildren().addAll(minPrice, new Label("to"), maxPrice);
        priceBox.getChildren().addAll(priceLabel, priceInputs);

        Button searchBtn = new Button("🔍  Search Rooms");
        searchBtn.setStyle("""
            -fx-background-color: #667eea;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 12 30;
            -fx-font-size: 14;
            -fx-font-weight: bold;
            -fx-cursor: hand;
            """);
        searchBtn.setOnAction(e -> {
            try {
                BigDecimal min = minPrice.getText().isEmpty() ? null : new BigDecimal(minPrice.getText());
                BigDecimal max = maxPrice.getText().isEmpty() ? null : new BigDecimal(maxPrice.getText());
                roomList.clear();
                roomList.addAll(roomService.filterRooms(min, max, typeCombo.getValue()));
            } catch (Exception ex) {
                showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        filterBox.getChildren().addAll(typeBox, priceBox, spacer, searchBtn);
        return filterBox;
    }

    private TableView<Room> createRoomTable() {
        TableView<Room> table = new TableView<>();
        table.setStyle("-fx-background-color: white; -fx-background-radius: 10;");

        TableColumn<Room, String> numberCol = new TableColumn<>("Room");
        numberCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));

        TableColumn<Room, Room.RoomType> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

        TableColumn<Room, BigDecimal> priceCol = new TableColumn<>("Price/Night (PKR)");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Room, Integer> capacityCol = new TableColumn<>("Guests");
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));

        TableColumn<Room, Void> actionCol = new TableColumn<>("Action");
        actionCol.setCellFactory(param -> new TableCell<>() {
            private final Button bookBtn = new Button("📅  Book Now");
            {
                bookBtn.setStyle("""
                    -fx-background-color: #27ae60;
                    -fx-text-fill: white;
                    -fx-background-radius: 5;
                    -fx-padding: 5 15;
                    -fx-cursor: hand;
                    """);
                bookBtn.setOnAction(event -> {
                    Room room = getTableView().getItems().get(getIndex());
                    BookingView bv = new BookingView(stage, room, currentUser);
                    bv.setOnBookingComplete(() -> {
                        try {
                            roomList.clear();
                            roomList.addAll(roomService.filterRooms(null, null, null));
                        } catch (SQLException ignored) {}
                    });
                    bv.show();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : bookBtn);
            }
        });

        table.getColumns().addAll(numberCol, typeCol, priceCol, capacityCol, actionCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        return table;
    }

    private VBox createMyBookingsContent() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        Label sectionLabel = new Label("My Bookings");
        sectionLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));

        bookingTable = createBookingTable();
        bookingList = FXCollections.observableArrayList();
        bookingTable.setItems(bookingList);
        VBox.setVgrow(bookingTable, Priority.ALWAYS);

        content.getChildren().addAll(sectionLabel, bookingTable);
        return content;
    }

    private TableView<Booking> createBookingTable() {
        TableView<Booking> table = new TableView<>();
        table.setStyle("-fx-background-color: white; -fx-background-radius: 10;");

        TableColumn<Booking, Integer> idCol = new TableColumn<>("Booking #");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(90);

        TableColumn<Booking, String> roomCol = new TableColumn<>("Room");
        roomCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));

        TableColumn<Booking, String> checkInCol = new TableColumn<>("Check-In");
        checkInCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getCheckInDate() != null ? b.getCheckInDate().format(DATE_FMT) : "");
            }
        });

        TableColumn<Booking, String> checkOutCol = new TableColumn<>("Check-Out");
        checkOutCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getCheckOutDate() != null ? b.getCheckOutDate().format(DATE_FMT) : "");
            }
        });

        TableColumn<Booking, BigDecimal> totalCol = new TableColumn<>("Total (PKR)");
        totalCol.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));

        TableColumn<Booking, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getBookingStatus() != null ? b.getBookingStatus().getDisplayName() : "");
            }
        });

        TableColumn<Booking, String> paymentCol = new TableColumn<>("Payment");
        paymentCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getPaymentStatus() != null ? b.getPaymentStatus().getDisplayName() : "");
            }
        });

        TableColumn<Booking, Void> actionsCol = new TableColumn<>("Actions");
        actionsCol.setPrefWidth(230);
        actionsCol.setCellFactory(param -> new TableCell<>() {
            private final Button invoiceBtn = new Button("🧾 Invoice");
            private final Button reviewBtn  = new Button("⭐ Review");
            private final HBox box = new HBox(6, invoiceBtn, reviewBtn);
            {
                String btnStyle = "-fx-background-radius:5;-fx-text-fill:white;-fx-padding:4 10;-fx-cursor:hand;";
                invoiceBtn.setStyle("-fx-background-color:#3498db;" + btnStyle);
                reviewBtn.setStyle("-fx-background-color:#f39c12;" + btnStyle);

                invoiceBtn.setOnAction(ev -> {
                    Booking b = getTableView().getItems().get(getIndex());
                    new InvoiceView(b).show();
                });
                reviewBtn.setOnAction(ev -> {
                    Booking b = getTableView().getItems().get(getIndex());
                    if (b.getBookingStatus() != Booking.BookingStatus.COMPLETED) {
                        showAlert(Alert.AlertType.WARNING, "Cannot Review",
                                "You can only review completed bookings.");
                        return;
                    }
                    ReviewView rv = new ReviewView(stage, b, currentUser);
                    rv.setOnReviewComplete(() -> showAlert(Alert.AlertType.INFORMATION,
                            "Thank You!", "Your review was submitted!"));
                    rv.show();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        table.getColumns().addAll(idCol, roomCol, checkInCol, checkOutCol,
                totalCol, statusCol, paymentCol, actionsCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        return table;
    }

    private void refreshBookingTable() {
        try {
            bookingList.clear();
            bookingList.addAll(bookingService.getBookingsForGuest(currentUser.getId()));
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load bookings: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
