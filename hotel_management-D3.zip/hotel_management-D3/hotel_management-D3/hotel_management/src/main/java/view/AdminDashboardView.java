// src/view/AdminDashboardView.java
package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Booking;
import model.Review;
import model.Room;
import model.User;
import service.BookingService;
import service.ReviewService;
import service.RoomService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class AdminDashboardView {
    private Stage stage;
    private User currentUser;
    private RoomService roomService;
    private BookingService bookingService;
    private ReviewService reviewService;
    private TableView<Room> roomTable;
    private ObservableList<Room> roomList;

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public AdminDashboardView(Stage stage, User user) {
        this.stage = stage;
        this.currentUser = user;
        this.roomService = new RoomService();
        this.bookingService = new BookingService();
        this.reviewService = new ReviewService();
    }

    public void show() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f6fa;");
        root.setTop(createHeader());

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab roomsTab      = new Tab("🏠  Rooms",      createRoomsContent());
        Tab bookingsTab   = new Tab("📋  Bookings",   createBookingsContent());
        Tab reportsTab    = new Tab("📊  Reports",    createReportsContent());
        Tab reviewsTab    = new Tab("⭐  Reviews",    createReviewsContent());

        tabPane.getTabs().addAll(roomsTab, bookingsTab, reportsTab, reviewsTab);
        root.setCenter(tabPane);

        Scene scene = new Scene(root, 1300, 800);
        stage.setTitle("Admin Dashboard — " + currentUser.getName());
        stage.setScene(scene);
        stage.setMaximized(true);
    }

    // ─────────────────────────────── HEADER ──────────────────────────────────

    private HBox createHeader() {
        HBox header = new HBox(20);
        header.setPadding(new Insets(15, 20, 15, 20));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setStyle("""
            -fx-background-color: #2c3e50;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 5);
            """);

        Label titleLabel = new Label("🏨  Hotel Management System");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        titleLabel.setTextFill(Color.WHITE);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label userLabel = new Label("Welcome, " + currentUser.getName() + " (Admin)");
        userLabel.setFont(Font.font("Segoe UI", 14));
        userLabel.setTextFill(Color.WHITE);

        Button logoutButton = new Button("Logout");
        logoutButton.setStyle("""
            -fx-background-color: #e74c3c;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 8 20;
            -fx-cursor: hand;
            """);
        logoutButton.setOnAction(e -> new LoginView(stage).show());

        header.getChildren().addAll(titleLabel, spacer, userLabel, logoutButton);
        return header;
    }

    // ─────────────────────────────── ROOMS TAB ───────────────────────────────

    private VBox createRoomsContent() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        HBox statsBox = createStatsCards();

        Label sectionLabel = new Label("Room Management");
        sectionLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));

        HBox actionBox = new HBox(10);
        Button addRoomBtn    = styleBtn(new Button("➕  Add Room"),    "#27ae60");
        Button editRoomBtn   = styleBtn(new Button("✏️  Edit Room"),   "#f39c12");
        Button deleteRoomBtn = styleBtn(new Button("🗑️  Delete Room"), "#e74c3c");
        Button refreshBtn    = styleBtn(new Button("🔄  Refresh"),     "#3498db");

        addRoomBtn.setOnAction(e -> showAddRoomDialog());
        editRoomBtn.setOnAction(e -> showEditRoomDialog());
        deleteRoomBtn.setOnAction(e -> deleteSelectedRoom());
        refreshBtn.setOnAction(e -> refreshRoomTable());

        actionBox.getChildren().addAll(addRoomBtn, editRoomBtn, deleteRoomBtn, refreshBtn);

        roomTable = createRoomTable();
        roomList = FXCollections.observableArrayList();
        roomTable.setItems(roomList);
        VBox.setVgrow(roomTable, Priority.ALWAYS);

        content.getChildren().addAll(statsBox, sectionLabel, actionBox, roomTable);
        refreshRoomTable();
        return content;
    }

    private HBox createStatsCards() {
        HBox stats = new HBox(20);
        try {
            List<Room> rooms = roomService.getAllRooms();
            long total     = rooms.size();
            long available = rooms.stream().filter(r -> r.getStatus() == Room.RoomStatus.AVAILABLE).count();
            long occupied  = rooms.stream().filter(r -> r.getStatus() == Room.RoomStatus.OCCUPIED).count();
            long reserved  = rooms.stream().filter(r -> r.getStatus() == Room.RoomStatus.RESERVED).count();
            BigDecimal rev = bookingService.getRevenueForDateRange(
                    LocalDate.now().withDayOfMonth(1), LocalDate.now());

            stats.getChildren().addAll(
                createStatCard("Total Rooms",    String.valueOf(total),     "#3498db"),
                createStatCard("Available",       String.valueOf(available), "#27ae60"),
                createStatCard("Occupied",        String.valueOf(occupied),  "#e74c3c"),
                createStatCard("Reserved",        String.valueOf(reserved),  "#9b59b6"),
                createStatCard("Revenue (MTD)",  "PKR " + String.format("%,.0f", rev), "#f39c12")
            );
        } catch (SQLException e) {
            stats.getChildren().add(new Label("Failed to load stats."));
        }
        return stats;
    }

    private VBox createStatCard(String title, String value, String color) {
        VBox card = new VBox(5);
        card.setPadding(new Insets(15));
        card.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 10;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 5);
            -fx-min-width: 160;
            """);

        Label titleLabel = new Label(title);
        titleLabel.setTextFill(Color.GRAY);

        Label valueLabel = new Label(value);
        valueLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        valueLabel.setTextFill(Color.web(color));

        card.getChildren().addAll(titleLabel, valueLabel);
        return card;
    }

    private TableView<Room> createRoomTable() {
        TableView<Room> table = new TableView<>();
        table.setStyle("-fx-background-color: white; -fx-background-radius: 10;");

        TableColumn<Room, String> numberCol = new TableColumn<>("Room #");
        numberCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));

        TableColumn<Room, Room.RoomType> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

        TableColumn<Room, BigDecimal> priceCol = new TableColumn<>("Price (PKR)");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Room, Room.RoomStatus> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        TableColumn<Room, Integer> capacityCol = new TableColumn<>("Capacity");
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));

        table.getColumns().addAll(numberCol, typeCol, priceCol, capacityCol, statusCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        return table;
    }

    private void showAddRoomDialog() {
        Dialog<Room> dialog = new Dialog<>();
        dialog.setTitle("Add New Room");
        dialog.setHeaderText("Enter room details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField roomNumber = new TextField();
        ComboBox<Room.RoomType> type = new ComboBox<>(
            FXCollections.observableArrayList(Room.RoomType.values()));
        type.setValue(Room.RoomType.SINGLE);
        TextField price    = new TextField();
        TextField capacity = new TextField();
        TextArea  description = new TextArea();
        description.setPrefRowCount(3);
        TextField amenities = new TextField();

        grid.addRow(0, new Label("Room Number:"),    roomNumber);
        grid.addRow(1, new Label("Type:"),           type);
        grid.addRow(2, new Label("Price per night:"), price);
        grid.addRow(3, new Label("Capacity:"),        capacity);
        grid.addRow(4, new Label("Description:"),     description);
        grid.addRow(5, new Label("Amenities:"),       amenities);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    Room room = new Room();
                    room.setRoomNumber(roomNumber.getText());
                    room.setType(type.getValue());
                    room.setPrice(new BigDecimal(price.getText()));
                    room.setCapacity(Integer.parseInt(capacity.getText()));
                    room.setDescription(description.getText());
                    room.setAmenities(amenities.getText());
                    return room;
                } catch (Exception e) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Invalid input data");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(room -> {
            try {
                roomService.addRoom(
                    room.getRoomNumber(), room.getType(), room.getPrice(),
                    room.getCapacity(), room.getDescription(), room.getAmenities());
                refreshRoomTable();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Room added successfully!");
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Error", e.getMessage());
            }
        });
    }

    private void showEditRoomDialog() {
        Room selected = roomTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a room to edit");
            return;
        }
        Dialog<Room> dialog = new Dialog<>();
        dialog.setTitle("Edit Room");
        dialog.setHeaderText("Edit room details");

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField roomNumber = new TextField(selected.getRoomNumber());
        ComboBox<Room.RoomType> type = new ComboBox<>(
            FXCollections.observableArrayList(Room.RoomType.values()));
        type.setValue(selected.getType());
        TextField price     = new TextField(selected.getPrice().toString());
        TextField capacity  = new TextField(String.valueOf(selected.getCapacity()));
        TextArea  desc      = new TextArea(selected.getDescription());
        desc.setPrefRowCount(3);
        TextField amenities = new TextField(selected.getAmenities());
        ComboBox<Room.RoomStatus> status = new ComboBox<>(
            FXCollections.observableArrayList(Room.RoomStatus.values()));
        status.setValue(selected.getStatus());

        grid.addRow(0, new Label("Room Number:"),    roomNumber);
        grid.addRow(1, new Label("Type:"),           type);
        grid.addRow(2, new Label("Price per night:"), price);
        grid.addRow(3, new Label("Capacity:"),        capacity);
        grid.addRow(4, new Label("Status:"),          status);
        grid.addRow(5, new Label("Description:"),     desc);
        grid.addRow(6, new Label("Amenities:"),       amenities);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    selected.setRoomNumber(roomNumber.getText());
                    selected.setType(type.getValue());
                    selected.setPrice(new BigDecimal(price.getText()));
                    selected.setCapacity(Integer.parseInt(capacity.getText()));
                    selected.setStatus(status.getValue());
                    selected.setDescription(desc.getText());
                    selected.setAmenities(amenities.getText());
                    return selected;
                } catch (Exception e) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Invalid input");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(room -> {
            try {
                roomService.updateRoom(room);
                refreshRoomTable();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Room updated successfully!");
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Error", e.getMessage());
            }
        });
    }

    private void deleteSelectedRoom() {
        Room selected = roomTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a room to delete");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Delete");
        confirm.setContentText("Delete room " + selected.getRoomNumber() + "?");
        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    roomService.deleteRoom(selected.getId());
                    refreshRoomTable();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Room deleted.");
                } catch (SQLException e) {
                    showAlert(Alert.AlertType.ERROR, "Error", e.getMessage());
                }
            }
        });
    }

    private void refreshRoomTable() {
        try {
            roomList.clear();
            roomList.addAll(roomService.getAllRooms());
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load rooms: " + e.getMessage());
        }
    }

    // ─────────────────────────────── BOOKINGS TAB ────────────────────────────

    private VBox createBookingsContent() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        Label sectionLabel = new Label("All Bookings");
        sectionLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));

        TableView<Booking> table = new TableView<>();
        table.setStyle("-fx-background-color: white; -fx-background-radius: 10;");

        ObservableList<Booking> bookingList = FXCollections.observableArrayList();
        table.setItems(bookingList);
        VBox.setVgrow(table, Priority.ALWAYS);

        TableColumn<Booking, Integer> idCol = new TableColumn<>("#");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id")); idCol.setPrefWidth(60);

        TableColumn<Booking, String> guestCol = new TableColumn<>("Guest");
        guestCol.setCellValueFactory(new PropertyValueFactory<>("guestName"));

        TableColumn<Booking, String> roomCol = new TableColumn<>("Room");
        roomCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));

        TableColumn<Booking, String> inCol = new TableColumn<>("Check-In");
        inCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getCheckInDate() != null ? b.getCheckInDate().format(DATE_FMT) : "");
            }
        });

        TableColumn<Booking, String> outCol = new TableColumn<>("Check-Out");
        outCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getCheckOutDate() != null ? b.getCheckOutDate().format(DATE_FMT) : "");
            }
        });

        TableColumn<Booking, BigDecimal> totalCol = new TableColumn<>("Total (PKR)");
        totalCol.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));

        TableColumn<Booking, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getBookingStatus() != null ? b.getBookingStatus().getDisplayName() : "");
            }
        });

        TableColumn<Booking, String> payCol = new TableColumn<>("Payment");
        payCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getPaymentStatus() != null ? b.getPaymentStatus().getDisplayName() : "");
            }
        });

        TableColumn<Booking, Void> actCol = new TableColumn<>("Actions");
        actCol.setPrefWidth(260);
        actCol.setCellFactory(param -> new TableCell<>() {
            private final Button paidBtn    = new Button("✅ Mark Paid");
            private final Button invoiceBtn = new Button("🧾 Invoice");
            private final Button cancelBtn  = new Button("❌ Cancel");
            private final HBox box = new HBox(5, paidBtn, invoiceBtn, cancelBtn);
            {
                String bs = "-fx-background-radius:5;-fx-text-fill:white;-fx-padding:4 8;-fx-cursor:hand;";
                paidBtn.setStyle("-fx-background-color:#27ae60;" + bs);
                invoiceBtn.setStyle("-fx-background-color:#3498db;" + bs);
                cancelBtn.setStyle("-fx-background-color:#e74c3c;" + bs);

                paidBtn.setOnAction(ev -> {
                    Booking b = getTableView().getItems().get(getIndex());
                    try {
                        bookingService.markAsPaid(b.getId());
                        bookingList.clear();
                        bookingList.addAll(bookingService.getAllBookings());
                        showAlert(Alert.AlertType.INFORMATION, "Updated", "Booking marked as Paid and Completed.");
                    } catch (SQLException ex) {
                        showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
                    }
                });
                invoiceBtn.setOnAction(ev -> {
                    Booking b = getTableView().getItems().get(getIndex());
                    new InvoiceView(b).show();
                });
                cancelBtn.setOnAction(ev -> {
                    Booking b = getTableView().getItems().get(getIndex());
                    try {
                        bookingService.cancelBooking(b.getId());
                        bookingList.clear();
                        bookingList.addAll(bookingService.getAllBookings());
                        showAlert(Alert.AlertType.INFORMATION, "Cancelled", "Booking cancelled.");
                    } catch (SQLException ex) {
                        showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        table.getColumns().addAll(idCol, guestCol, roomCol, inCol, outCol,
                totalCol, statusCol, payCol, actCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        Button refreshBtn = styleBtn(new Button("🔄  Refresh Bookings"), "#3498db");
        refreshBtn.setOnAction(e -> {
            try {
                bookingList.clear();
                bookingList.addAll(bookingService.getAllBookings());
            } catch (SQLException ex) {
                showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        // Initial load
        try { bookingList.addAll(bookingService.getAllBookings()); }
        catch (SQLException ex) { /* handled silently */ }

        content.getChildren().addAll(sectionLabel, refreshBtn, table);
        return content;
    }

    // ─────────────────────────────── REPORTS TAB ─────────────────────────────

    private VBox createReportsContent() {
        VBox content = new VBox(25);
        content.setPadding(new Insets(25));

        Label sectionLabel = new Label("📊  Revenue & Occupancy Reports");
        sectionLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));

        // Revenue section
        VBox revenueCard = new VBox(15);
        revenueCard.setPadding(new Insets(20));
        revenueCard.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 10;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);
            """);

        Label revTitle = new Label("Revenue Report");
        revTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));

        HBox dateRow = new HBox(15);
        dateRow.setAlignment(Pos.CENTER_LEFT);
        Label fromLabel = new Label("From:");
        DatePicker fromPicker = new DatePicker(LocalDate.now().withDayOfMonth(1));
        Label toLabel = new Label("To:");
        DatePicker toPicker = new DatePicker(LocalDate.now());
        Button calcBtn = styleBtn(new Button("Calculate Revenue"), "#3498db");

        Label revResultLabel = new Label("Select a date range and click Calculate");
        revResultLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));

        TableView<Booking> revTable = new TableView<>();
        revTable.setStyle("-fx-background-color: #f9f9f9;-fx-background-radius:8;");
        revTable.setPrefHeight(200);
        ObservableList<Booking> revList = FXCollections.observableArrayList();
        revTable.setItems(revList);

        TableColumn<Booking, String> gCol = new TableColumn<>("Guest");
        gCol.setCellValueFactory(new PropertyValueFactory<>("guestName"));
        TableColumn<Booking, String> rCol = new TableColumn<>("Room");
        rCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        TableColumn<Booking, BigDecimal> tCol = new TableColumn<>("Total (PKR)");
        tCol.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        TableColumn<Booking, String> dCol = new TableColumn<>("Check-In");
        dCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Booking b = (Booking) getTableRow().getItem();
                setText(b.getCheckInDate() != null ? b.getCheckInDate().format(DATE_FMT) : "");
            }
        });
        revTable.getColumns().addAll(gCol, rCol, tCol, dCol);
        revTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        calcBtn.setOnAction(e -> {
            try {
                LocalDate from = fromPicker.getValue();
                LocalDate to   = toPicker.getValue();
                BigDecimal rev = bookingService.getRevenueForDateRange(from, to);
                revResultLabel.setText("Total Revenue: PKR " + String.format("%,.2f", rev));
                revResultLabel.setTextFill(Color.web("#27ae60"));

                revList.clear();
                revList.addAll(bookingService.getBookingsByDateRange(from, to));
            } catch (SQLException ex) {
                showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        dateRow.getChildren().addAll(fromLabel, fromPicker, toLabel, toPicker, calcBtn);
        revenueCard.getChildren().addAll(revTitle, dateRow, revResultLabel, revTable);

        // Occupancy section
        VBox occupancyCard = new VBox(15);
        occupancyCard.setPadding(new Insets(20));
        occupancyCard.setStyle("""
            -fx-background-color: white;
            -fx-background-radius: 10;
            -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);
            """);

        Label occTitle = new Label("Room Occupancy Analytics");
        occTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));

        VBox occBars = new VBox(10);
        try {
            List<Object[]> stats = bookingService.getOccupancyStats();
            if (stats.isEmpty()) {
                occBars.getChildren().add(new Label("No booking data available yet."));
            } else {
                int maxCount = stats.stream().mapToInt(s -> (int) s[1]).max().orElse(1);
                for (Object[] row : stats) {
                    String type  = (String) row[0];
                    int count    = (int) row[1];
                    int rooms    = (int) row[2];
                    double pct   = rooms == 0 ? 0 : Math.min(100.0, (count * 100.0) / Math.max(rooms * 3, 1));

                    HBox barRow = new HBox(10);
                    barRow.setAlignment(Pos.CENTER_LEFT);

                    Label typeLbl = new Label(String.format("%-12s", type));
                    typeLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 13));
                    typeLbl.setPrefWidth(120);

                    StackPane barContainer = new StackPane();
                    barContainer.setStyle("-fx-background-color:#ecf0f1;-fx-background-radius:5;");
                    barContainer.setPrefHeight(24);
                    barContainer.setPrefWidth(400);

                    double barWidth = Math.max(10, (count * 400.0) / Math.max(maxCount, 1));
                    Region bar = new Region();
                    bar.setPrefHeight(24);
                    bar.setPrefWidth(barWidth);
                    bar.setMaxWidth(barWidth);
                    bar.setStyle("-fx-background-color:#3498db;-fx-background-radius:5;");
                    barContainer.getChildren().add(bar);
                    StackPane.setAlignment(bar, Pos.CENTER_LEFT);

                    Label countLbl = new Label(count + " bookings  |  " + rooms + " rooms  |  ~" + String.format("%.0f%%", pct) + " occ.");
                    countLbl.setTextFill(Color.GRAY);

                    barRow.getChildren().addAll(typeLbl, barContainer, countLbl);
                    occBars.getChildren().add(barRow);
                }
            }
        } catch (SQLException ex) {
            occBars.getChildren().add(new Label("Error loading occupancy: " + ex.getMessage()));
        }

        occupancyCard.getChildren().addAll(occTitle, occBars);
        content.getChildren().addAll(sectionLabel, revenueCard, occupancyCard);
        return content;
    }

    // ─────────────────────────────── REVIEWS TAB ─────────────────────────────

    private VBox createReviewsContent() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        Label sectionLabel = new Label("⭐  Guest Reviews & Feedback");
        sectionLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));

        TableView<Review> table = new TableView<>();
        table.setStyle("-fx-background-color: white; -fx-background-radius: 10;");
        ObservableList<Review> reviewList = FXCollections.observableArrayList();
        table.setItems(reviewList);
        VBox.setVgrow(table, Priority.ALWAYS);

        TableColumn<Review, Integer> idCol = new TableColumn<>("#");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id")); idCol.setPrefWidth(50);

        TableColumn<Review, String> guestCol = new TableColumn<>("Guest");
        guestCol.setCellValueFactory(new PropertyValueFactory<>("guestName"));

        TableColumn<Review, String> roomCol = new TableColumn<>("Room");
        roomCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));

        TableColumn<Review, Integer> ratingCol = new TableColumn<>("Rating");
        ratingCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(Integer r, boolean empty) {
                super.updateItem(r, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Review rv = (Review) getTableRow().getItem();
                setText(rv.getStarDisplay() + "  (" + rv.getRating() + "/5)");
            }
        });

        TableColumn<Review, String> commentCol = new TableColumn<>("Comment");
        commentCol.setCellValueFactory(new PropertyValueFactory<>("comment"));
        commentCol.setPrefWidth(350);

        TableColumn<Review, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) { setText(null); return; }
                Review rv = (Review) getTableRow().getItem();
                setText(rv.getCreatedAt() != null ? rv.getCreatedAt().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")) : "");
            }
        });

        table.getColumns().addAll(idCol, guestCol, roomCol, ratingCol, commentCol, dateCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        Button refreshBtn = styleBtn(new Button("🔄  Refresh Reviews"), "#3498db");
        refreshBtn.setOnAction(e -> {
            try {
                reviewList.clear();
                reviewList.addAll(reviewService.getAllReviews());
            } catch (SQLException ex) {
                showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
            }
        });

        try { reviewList.addAll(reviewService.getAllReviews()); }
        catch (SQLException ex) { /* silently */ }

        content.getChildren().addAll(sectionLabel, refreshBtn, table);
        return content;
    }

    // ─────────────────────────────── HELPERS ─────────────────────────────────

    private Button styleBtn(Button btn, String color) {
        btn.setStyle(String.format("""
            -fx-background-color: %s;
            -fx-text-fill: white;
            -fx-background-radius: 5;
            -fx-padding: 10 20;
            -fx-font-size: 13;
            -fx-cursor: hand;
            """, color));
        return btn;
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
