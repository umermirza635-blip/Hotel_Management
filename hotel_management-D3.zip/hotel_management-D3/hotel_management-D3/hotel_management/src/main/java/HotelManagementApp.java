// src/HotelManagementApp.java
import javafx.application.Application;
import javafx.stage.Stage;
import util.DatabaseConnection;
import view.LoginView;

public class HotelManagementApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Initialize database
        DatabaseConnection.initializeDatabase();
        
        // Show login view
        LoginView loginView = new LoginView(primaryStage);
        loginView.show();
    }

    @Override
    public void stop() {
        DatabaseConnection.closeConnection();
    }

    public static void main(String[] args) {
        launch(args);
    }
}