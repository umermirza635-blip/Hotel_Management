// src/service/BookingService.java
package service;

import dao.BookingDAO;
import dao.RoomDAO;
import model.Booking;
import model.Room;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class BookingService {

    // GST rate: 16% (standard service tax in Pakistan/regional hotels)
    public static final BigDecimal GST_RATE = new BigDecimal("0.16");
    public static final BigDecimal SERVICE_CHARGE_RATE = new BigDecimal("0.05");

    private final BookingDAO bookingDAO;
    private final RoomDAO roomDAO;

    public BookingService() {
        this.bookingDAO = new BookingDAO();
        this.roomDAO = new RoomDAO();
    }

    /**
     * Create a new booking with full tax calculation.
     */
    public Booking createBooking(int guestId, int roomId,
                                  LocalDate checkIn, LocalDate checkOut)
            throws SQLException, IllegalArgumentException {

        if (checkIn == null || checkOut == null) {
            throw new IllegalArgumentException("Check-in and check-out dates are required.");
        }
        if (!checkOut.isAfter(checkIn)) {
            throw new IllegalArgumentException("Check-out must be after check-in.");
        }

        Room room = roomDAO.findById(roomId);
        if (room == null) throw new IllegalArgumentException("Room not found.");
        if (room.getStatus() != Room.RoomStatus.AVAILABLE
                && room.getStatus() != Room.RoomStatus.RESERVED) {
            throw new IllegalArgumentException("Room is not available for booking.");
        }

        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        BigDecimal subtotal = room.getPrice().multiply(BigDecimal.valueOf(nights));
        BigDecimal gst = subtotal.multiply(GST_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal serviceCharge = subtotal.multiply(SERVICE_CHARGE_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal taxTotal = gst.add(serviceCharge);
        BigDecimal grandTotal = subtotal.add(taxTotal);

        Booking booking = new Booking();
        booking.setGuestId(guestId);
        booking.setRoomId(roomId);
        booking.setCheckInDate(checkIn);
        booking.setCheckOutDate(checkOut);
        booking.setPricePerNight(room.getPrice());
        booking.setSubtotal(subtotal);
        booking.setTaxAmount(taxTotal);
        booking.setTotalAmount(grandTotal);
        booking.setPaymentStatus(Booking.PaymentStatus.PENDING);
        booking.setBookingStatus(Booking.BookingStatus.RESERVED);

        Booking saved = bookingDAO.create(booking);

        // Mark room as reserved
        room.setStatus(Room.RoomStatus.RESERVED);
        roomDAO.update(room);

        return saved;
    }

    /**
     * Mark booking as PAID and transition to COMPLETED if checkout date passed.
     */
    public void markAsPaid(int bookingId) throws SQLException {
        bookingDAO.updatePaymentStatus(bookingId, Booking.PaymentStatus.PAID);
        bookingDAO.updateBookingStatus(bookingId, Booking.BookingStatus.COMPLETED);

        Booking b = bookingDAO.findById(bookingId);
        if (b != null) {
            Room room = roomDAO.findById(b.getRoomId());
            if (room != null) {
                room.setStatus(Room.RoomStatus.AVAILABLE);
                roomDAO.update(room);
            }
        }
    }

    public void cancelBooking(int bookingId) throws SQLException {
        bookingDAO.updateBookingStatus(bookingId, Booking.BookingStatus.CANCELLED);
        Booking b = bookingDAO.findById(bookingId);
        if (b != null) {
            Room room = roomDAO.findById(b.getRoomId());
            if (room != null) {
                room.setStatus(Room.RoomStatus.AVAILABLE);
                roomDAO.update(room);
            }
        }
    }

    public Booking getBookingById(int id) throws SQLException {
        return bookingDAO.findById(id);
    }

    public List<Booking> getBookingsForGuest(int guestId) throws SQLException {
        return bookingDAO.findByGuestId(guestId);
    }

    public List<Booking> getAllBookings() throws SQLException {
        return bookingDAO.findAll();
    }

    public List<Booking> getBookingsByDateRange(LocalDate from, LocalDate to) throws SQLException {
        return bookingDAO.findByDateRange(from, to);
    }

    public BigDecimal getRevenueForDateRange(LocalDate from, LocalDate to) throws SQLException {
        return bookingDAO.getTotalRevenueBetween(from, to);
    }

    public List<Object[]> getOccupancyStats() throws SQLException {
        return bookingDAO.getRoomOccupancyStats();
    }
}
