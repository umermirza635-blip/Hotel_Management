// src/service/ReviewService.java
package service;

import dao.ReviewDAO;
import model.Review;

import java.sql.SQLException;
import java.util.List;

public class ReviewService {

    private final ReviewDAO reviewDAO;

    public ReviewService() {
        this.reviewDAO = new ReviewDAO();
    }

    public Review submitReview(int bookingId, int guestId, int roomId,
                                int rating, String comment)
            throws SQLException, IllegalArgumentException {

        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5.");
        }
        if (comment == null || comment.trim().isEmpty()) {
            throw new IllegalArgumentException("Comment cannot be empty.");
        }
        if (reviewDAO.hasReviewedBooking(bookingId)) {
            throw new IllegalArgumentException("You have already reviewed this booking.");
        }

        Review review = new Review(bookingId, guestId, roomId, rating, comment.trim());
        return reviewDAO.create(review);
    }

    public List<Review> getAllReviews() throws SQLException {
        return reviewDAO.findAll();
    }

    public List<Review> getReviewsByGuest(int guestId) throws SQLException {
        return reviewDAO.findByGuestId(guestId);
    }
}
