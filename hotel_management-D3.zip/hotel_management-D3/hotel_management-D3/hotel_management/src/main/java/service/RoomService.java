// src/service/RoomService.java
package service;

import dao.RoomDAO;
import model.Room;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class RoomService {
    private RoomDAO roomDAO;

    public RoomService() {
        this.roomDAO = new RoomDAO();
    }

    public Room addRoom(String roomNumber, Room.RoomType type, BigDecimal price, 
                       int capacity, String description, String amenities) 
            throws SQLException, IllegalArgumentException {
        
        validateRoomData(roomNumber, type, price, capacity);
        
        if (roomDAO.roomNumberExists(roomNumber)) {
            throw new IllegalArgumentException("Room number already exists");
        }

        Room room = new Room(roomNumber, type, price, capacity);
        room.setDescription(description);
        room.setAmenities(amenities);
        
        return roomDAO.create(room);
    }

    public Room updateRoom(Room room) throws SQLException, IllegalArgumentException {
        validateRoomData(room.getRoomNumber(), room.getType(), room.getPrice(), room.getCapacity());
        return roomDAO.update(room);
    }

    public void deleteRoom(int id) throws SQLException {
        roomDAO.delete(id);
    }

    public List<Room> getAllRooms() throws SQLException {
        return roomDAO.findAll();
    }

    public List<Room> filterRooms(BigDecimal minPrice, BigDecimal maxPrice, Room.RoomType type) 
            throws SQLException {
        return roomDAO.findByFilters(minPrice, maxPrice, type);
    }

    private void validateRoomData(String roomNumber, Room.RoomType type, 
                                  BigDecimal price, int capacity) 
            throws IllegalArgumentException {
        
        if (roomNumber == null || roomNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Room number is required");
        }
        if (type == null) {
            throw new IllegalArgumentException("Room type is required");
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Valid price is required");
        }
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be greater than 0");
        }
    }
}