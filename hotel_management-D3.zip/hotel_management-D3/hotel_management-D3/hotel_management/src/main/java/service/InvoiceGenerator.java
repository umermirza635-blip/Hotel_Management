// src/service/InvoiceGenerator.java
package service;

import model.Booking;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

public class InvoiceGenerator {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final String HOTEL_NAME = "Grand Hotel Management System";
    private static final String HOTEL_ADDRESS = "123 Main Boulevard, Islamabad, Pakistan";
    private static final String HOTEL_PHONE = "+92-51-1234567";
    private static final String HOTEL_EMAIL = "info@grandhotel.com";

    /**
     * Generates a formatted receipt string for a booking.
     */
    public static String generateInvoiceText(Booking booking) {
        StringBuilder sb = new StringBuilder();
        String line = "═".repeat(56);
        String thinLine = "─".repeat(56);

        sb.append(line).append("\n");
        sb.append(center(HOTEL_NAME, 56)).append("\n");
        sb.append(center(HOTEL_ADDRESS, 56)).append("\n");
        sb.append(center("Tel: " + HOTEL_PHONE + " | " + HOTEL_EMAIL, 56)).append("\n");
        sb.append(line).append("\n");
        sb.append(center("INVOICE / RECEIPT", 56)).append("\n");
        sb.append(line).append("\n\n");

        sb.append(String.format("%-20s: #%06d%n", "Invoice No", booking.getId()));
        sb.append(String.format("%-20s: %s%n", "Guest Name", booking.getGuestName()));
        sb.append(String.format("%-20s: %s%n", "Room Number", booking.getRoomNumber()));
        sb.append(String.format("%-20s: %s%n", "Room Type",
                booking.getRoomType() != null ? booking.getRoomType().getDisplayName() : "N/A"));
        sb.append(String.format("%-20s: %s%n", "Check-In",
                booking.getCheckInDate().format(DATE_FMT)));
        sb.append(String.format("%-20s: %s%n", "Check-Out",
                booking.getCheckOutDate().format(DATE_FMT)));
        sb.append(String.format("%-20s: %d night(s)%n", "Duration", booking.getNights()));
        sb.append("\n");
        sb.append(thinLine).append("\n");
        sb.append(String.format("%-30s %s%n", "DESCRIPTION", "AMOUNT (PKR)"));
        sb.append(thinLine).append("\n");

        sb.append(String.format("%-30s PKR %,.2f%n",
                "Room Rate (per night)", booking.getPricePerNight()));
        sb.append(String.format("%-30s PKR %,.2f%n",
                "Nights x " + booking.getNights(), booking.getSubtotal()));

        // Break down tax
        BigDecimal gst = booking.getSubtotal()
                .multiply(BookingService.GST_RATE)
                .setScale(2, java.math.RoundingMode.HALF_UP);
        BigDecimal svc = booking.getSubtotal()
                .multiply(BookingService.SERVICE_CHARGE_RATE)
                .setScale(2, java.math.RoundingMode.HALF_UP);

        sb.append(String.format("%-30s PKR %,.2f%n", "GST (16%)", gst));
        sb.append(String.format("%-30s PKR %,.2f%n", "Service Charge (5%)", svc));
        sb.append(thinLine).append("\n");
        sb.append(String.format("%-30s PKR %,.2f%n", "TOTAL", booking.getTotalAmount()));
        sb.append(thinLine).append("\n\n");

        sb.append(String.format("%-20s: %s%n", "Booking Status",
                booking.getBookingStatus().getDisplayName()));
        sb.append(String.format("%-20s: %s%n", "Payment Status",
                booking.getPaymentStatus().getDisplayName()));

        sb.append("\n").append(line).append("\n");
        sb.append(center("Thank you for choosing " + HOTEL_NAME + "!", 56)).append("\n");
        sb.append(center("We hope to see you again soon.", 56)).append("\n");
        sb.append(line).append("\n");

        return sb.toString();
    }

    /**
     * Saves the invoice as a .txt file and returns the path.
     */
    public static String saveInvoiceToFile(Booking booking) throws IOException {
        String filename = "Invoice_" + String.format("%06d", booking.getId()) + "_"
                + booking.getCheckInDate().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".txt";
        String dir = System.getProperty("user.home") + File.separator + "HotelInvoices";
        new File(dir).mkdirs();
        String path = dir + File.separator + filename;

        try (FileWriter fw = new FileWriter(path)) {
            fw.write(generateInvoiceText(booking));
        }
        return path;
    }

    private static String center(String text, int width) {
        if (text.length() >= width) return text;
        int pad = (width - text.length()) / 2;
        return " ".repeat(pad) + text;
    }
}
