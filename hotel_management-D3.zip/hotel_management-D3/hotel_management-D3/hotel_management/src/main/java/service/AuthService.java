// src/service/AuthService.java
package service;

import dao.UserDAO;
import model.User;

import java.sql.SQLException;

public class AuthService {
    private UserDAO userDAO;

    public AuthService() {
        this.userDAO = new UserDAO();
    }

    public User register(String name, String email, String password, User.UserRole role) 
            throws SQLException, IllegalArgumentException {
        
        // Validation
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name is required");
        }
        if (email == null || !email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            throw new IllegalArgumentException("Valid email is required");
        }
        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters");
        }
        
        // Check if email exists
        if (userDAO.emailExists(email)) {
            throw new IllegalArgumentException("Email already registered");
        }

        User user = new User(name, email, password, role);
        return userDAO.create(user);
    }

    public User login(String email, String password) throws SQLException, IllegalArgumentException {
        if (email == null || password == null) {
            throw new IllegalArgumentException("Email and password are required");
        }

        User user = userDAO.findByEmailAndPassword(email, password);
        
        if (user == null) {
            throw new IllegalArgumentException("Invalid credentials");
        }

        return user;
    }
}